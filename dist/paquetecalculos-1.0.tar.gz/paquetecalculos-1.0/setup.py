from setuptools import setup

setup(
    name='paquetecalculos',
    version = '1.0',
    description='Paquete de redondeo y potencia',
    author='J.Rengifo',
    author_email='wrengifo@unicauca.edu.co',
    url = 'wrengifo.com',
    packages=['c11_Paquetes','calculos','calculos.redondeo_potencia']

# en cmd de windows <C:\Users\Stark\Documents\PracticasPython> python setup.py sdist>
)