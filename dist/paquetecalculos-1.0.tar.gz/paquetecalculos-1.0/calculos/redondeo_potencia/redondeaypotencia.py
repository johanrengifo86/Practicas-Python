def potencia(base,exponente):
    print('EL resultado de la potencia es: ', base ** exponente)

def redondear(numero):
    print('El resultado del redondeo es: ', round(numero))
