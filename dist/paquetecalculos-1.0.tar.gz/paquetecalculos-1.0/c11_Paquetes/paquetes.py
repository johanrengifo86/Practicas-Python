#===================================
# Paquetes
#===================================
# - Son Directorios donde se almacenarán módulos relacionados entre sí.
#
# - Sirven para organizar y reutilizar módulos
#
# - Para crear un paquete se crea una carpeta con un archivo __init__.py
#
#=======================================================================